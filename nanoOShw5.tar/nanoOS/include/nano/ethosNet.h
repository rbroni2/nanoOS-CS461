//______________________________________________________________________________
// Kernel-specific network-related definitions.
//______________________________________________________________________________

#ifndef __ETHOS_NET_H__
#define __ETHOS_NET_H__

#include <ethos/net/netInterface.h>

Connection          *shadowdaemonConnection;     // Connection to shadowdaemon connection.

#endif
