#include <nano/common.h>
#include <nano/mm.h>
#include <nano/debug.h>
#include <nano/pageTable.h>
#include <nano/xenPageTable.h>
#include <nano/archPageTable.h>
#include <nano/memory.h>
#include <nano/physicalInfo.h>
#include <nano/fmt.h>
int i = 0;
//
//
// READ ME:  In this file is my HW 4 and 5 hw4 seems to work as intended.
//  However with hw5 the page table setting works and I have code for insert and remove but they both use premade functions from nanoOS
//  and as far as I can tell maybe I put in bad values for testing page fault(I was it works I believe now).  As for making a copy I got quite lost on how to do it.
//
//
void setCurrent(vaddr_t vaddr){
	currentPt = (pt_t) vaddr;
//	start_info.pt_base = currentPT;
}
void ptePrint(ptentry_t pte){
	i++;
	if((pte & _PAGE_PRESENT) != 0){ 
		printfLog("0x%"PRIpte"\n", pte);
		printfLog("|P|");
		if((pte & _PAGE_RW) != 0){
			printfLog("R/W|");
		}else{
			printfLog("R|");
		}
		if((pte & _PAGE_USER) != 0){
			printfLog("U|");
		}else{
			printfLog("S|");
		}
		if((pte & _PAGE_PWT) != 0){
			printfLog("WT|");
		}else{
			printfLog("WB|");
		}
		if((pte & _PAGE_PCD) != 0){
			printfLog("CD|");
		}else{
			printfLog("CE|");
		}
		if((pte & _PAGE_ACCESSED) != 0){
			printfLog("A|");
		}else {
			printfLog("-|");
		}
		if((pte & _PAGE_DIRTY) != 0){
			printfLog("D|");
		}else {
			printfLog("-|");
		}
		if((pte & _PAGE_PAT) != 0){
			printfLog("PAT|");
		}else {
			printfLog("-|");
		}
		printfLog("-|-|-|\n");
	} else{
		printfLog("0x%"PRIpte" (Page not Present)\n", pte);
		printfLog("|-|");
		if((pte & _PAGE_RW) != 0){
			printfLog("R/W|");
		}else{
			printfLog("R|");
		}
		if((pte & _PAGE_USER) != 0){
			printfLog("U|");
		}else{
			printfLog("S|");
		}
		if((pte & _PAGE_PWT) != 0){
			printfLog("WT|");
		}else{
			printfLog("WB|");
		}
		if((pte & _PAGE_PCD) != 0){
			printfLog("CD|");
		}else{
			printfLog("CE|");
		}
		if((pte & _PAGE_ACCESSED) != 0){
			printfLog("A|");
		}else {
			printfLog("-|");
		}
		if((pte & _PAGE_DIRTY) != 0){
			printfLog("D|");
		}else {
			printfLog("-|");
		}
		if((pte & _PAGE_PAT) != 0){
			printfLog("PAT|");
		}else {
			printfLog("-|");
		}
		printfLog("-|-|-|\n");
	}
}
void
MyPageTableWalk(vaddr_t vaddr) 
{
    
    pt_t table = currentPt; // current page table
    ptentry_t pte;  // current page table entry


    xprintLog("Walking address $[pointer]"PRIpte"\n", vaddr);

    xprintLog("CR3: $[pointer]\n", (ulong)table);

#ifdef HAS_L4
    pte = table[l4offset(vaddr)];
    if ((pte & _PAGE_PRESENT) == 0) 
	{
	    printfLog("L4: ");
   ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l4offset(vaddr),l4offset(vaddr));
	    return;
	}

    table = (ptentry_t *)pteToVirtual(pte);
    printfLog("L4: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l4offset(vaddr),l4offset(vaddr));
#endif

    pte = table[l3offset(vaddr)];
    if ((pte & _PAGE_PRESENT) == 0) 
	{
	    printfLog("L3: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l3offset(vaddr),l3offset(vaddr));
	    return;
	}
    table = (ptentry_t *)pteToVirtual(pte);
    printfLog("L3: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l3offset(vaddr),l3offset(vaddr));

    pte = table[l2offset(vaddr)];
    if ((pte & _PAGE_PRESENT) == 0) 
	{
	    printfLog("L2: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l2offset(vaddr),l2offset(vaddr));
	    return;
	}
    table = (ptentry_t *)pteToVirtual(pte);
    printfLog("L2: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l2offset(vaddr),l2offset(vaddr));

    pte = table[l1offset(vaddr)];
    if ((pte & _PAGE_PRESENT) == 0) 
	{
	    printfLog("L1: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l1offset(vaddr),l1offset(vaddr));
	    return;
	}
    table = (ptentry_t *)pteToVirtual(pte);
    printfLog("L1: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l1offset(vaddr),l1offset(vaddr));
}
void
MyPageTablePrint(){
	vaddr_t temp = (vaddr_t)currentPt;
	pt_t table = currentPt; // current page table
    ptentry_t pte;  // current page table entry


    xprintLog("Walking address $[pointer]"PRIpte"\n", (vaddr_t)currentPt);

    xprintLog("CR3: $[pointer]\n", (ulong)table);

#ifdef HAS_L4
    pte = table[l4offset((vaddr_t)currentPt)];
    if ((pte & _PAGE_PRESENT) == 0) 
	{
	    printfLog("L4: ");
   ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l4offset((vaddr_t)currentPt),l4offset((vaddr_t)currentPt));
	    
	    return;
	} else{

    table = (ptentry_t *)pteToVirtual(pte);
    printfLog("L4: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l4offset((vaddr_t)currentPt),l4offset((vaddr_t)currentPt));
    currentPt = (pt_t)pteToVirtual(pte);
    MyPageTablePrint();
    currentPt = (pt_t)temp;
    }
#endif

    pte = table[l3offset((vaddr_t)currentPt)];
    if ((pte & _PAGE_PRESENT) == 0) 
	{
	    printfLog("L3: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l3offset((vaddr_t)currentPt),l3offset((vaddr_t)currentPt));
	    return;
	}else{
    table = (ptentry_t *)pteToVirtual(pte);
    printfLog("L3: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l3offset((vaddr_t)currentPt),l3offset((vaddr_t)currentPt));
    currentPt = (pt_t)pteToVirtual(pte);
    MyPageTablePrint();
    currentPt = (pt_t)temp;
    }
    pte = table[l2offset((vaddr_t)currentPt)];
    if ((pte & _PAGE_PRESENT) == 0) 
	{
	    printfLog("L2: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l2offset((vaddr_t)currentPt),l2offset((vaddr_t)currentPt));
	    return;
	}else{
    table = (ptentry_t *)pteToVirtual(pte);
    printfLog("L2: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l2offset((vaddr_t)currentPt),l2offset((vaddr_t)currentPt));
    currentPt = (pt_t)pteToVirtual(pte);
    MyPageTablePrint();
    currentPt = (pt_t)temp;
    }
    pte = table[l1offset((vaddr_t)currentPt)];
    if ((pte & _PAGE_PRESENT) == 0) 
	{
	    printfLog("L1: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l1offset((vaddr_t)currentPt),l1offset((vaddr_t)currentPt));
	    return;
	} else{
    table = (ptentry_t *)pteToVirtual(pte);
    printfLog("L1: ");
    ptePrint(pte);
    printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
	   l1offset((vaddr_t)currentPt),l1offset((vaddr_t)currentPt));
    currentPt = (pt_t)pteToVirtual(pte);
    MyPageTablePrint();
    currentPt = (pt_t)temp;
    }
    printfLog("%i\n", i);
}

//stuff for hw 5
mfn_t MypageTableMfn;
mfn_t MypageTableUserMfn;

void
MyarchPageTableLoad(void)//basically copied from archPageTableSpecific but had to comment out op[2]
{//idk why but op[2] doesn't work and errors
    if (!MypageTableMfn)
	{
	    return;
	}
			
    struct mmuext_op op[1]; // size is now 1

    op[0].cmd = MMUEXT_NEW_BASEPTR;
    op[0].arg1.mfn = MypageTableMfn;

    // user page table should not map kernel pages since both run at ring 0
    //op[1].cmd = MMUEXT_NEW_USER_BASEPTR;
  //  op[1].arg1.mfn = MypageTableUserMfn;
   // no User Sections should be fine based on what prof said
    int res = HYPERVISOR_mmuext_op(op, 1, NULL, DOMID_SELF);//changed to 1
    if (res < 0)
	{
	    xprintLog("archPageTableSwitch: error $[int]\n", res);
	    BUG();
	}
}

void
MyarchPageTableSwitch(pt_t pt)
{
    MypageTableMfn     = virtualToMfn((vaddr_t)pt);
    MypageTableUserMfn = virtualToMfn((vaddr_t)USER_BASEPTR(pt));
    MyarchPageTableLoad();

    currentPt = pt;

}	
void
setCurrentPageTable(vaddr_t pageTable)//default page table switch function from Arch Page Table Specific
{ // with some changes due to getting vaddr_t instead of pt_t
	MyarchPageTableSwitch((pt_t) pageTable);
}

void
MyPageTableInsert(                  ///< page table 
		    vaddr_t vaddr,                 ///< the new virtual address
		    maddr_t maddr,                 ///< the current machine address of the page to be mapped in
		    ulong permission        ///< permissions
		    )
{

   pt_t pt = currentPt;
    archPageTableInsert(pt, vaddr,maddr,(permission_t)permission);//this should work idk
// had trouble testing it
}
void removeTest(vaddr_t vaddr){//used in testing
	pt_t table = currentPt; // current page table
    ptentry_t pte;  // current page table entry
	pte = table[l4offset(vaddr)];
	ptePrint(pte);
  //  printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
//	   l4offset((vaddr_t)currentPt),l4offset((vaddr_t)currentPt));
	MyPageTableRemove((vaddr_t)table);
//	printfLog(" (0x%p) [0x%x][%d]\n", (ulong)table,
//	   l4offset((vaddr_t)currentPt),l4offset((vaddr_t)currentPt));
//	ptePrint(pte);
}
// Is page faulting idk why? maybe userspace problem with regards to pages
// Similar to problem with switching pages?
// Thought It may have to do with me calling my version of pageTableswitch 
// so that the global vars weren't updated but changing it to my version didn't fix the problem so that shouldn't be it

void
MyPageTableRemove(
		    vaddr_t  vaddr
		    )
{
    pt_t pt = currentPt;
    archPageTableRemove(pt,vaddr); 
}