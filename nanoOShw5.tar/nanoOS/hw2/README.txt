My malloc and free do not work correctly but I have implemented
them to the best of my abilities given the confusion I had before
and during the extension as I now have some understanding of list.h
and have managed to get my makefile seemingly working.
However list.h is still kinda confusing to me, my tests are bad, and the
logic for my malloc especially doesn't really work it doesn't combine
memory nor does space checking happen which obviously is really bad but
implementing them seemed to be beyond me unfortunately.
I also did not manage to get the flags implemented honestly they were 
kinda confusing too and getting malloc working normally first was
more of a priority. Currently I ran out of time trying to get my malloc
to make and compile properly but as mentioned above make is fine
when malloc and free are disincluded as they do not work and I could not
solve them unfortunately. Lastly, while they make correctly  I am not 100%
confident in the way I replaced write and exit.  I am more confident in
exit's replacement but their were so many prints in nanoOS and I couldn't
decern which was the correct one.
Thanks for reading.
