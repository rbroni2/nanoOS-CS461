#include<nano/memstrprint.h>
#include<nano//common.h>
#include<nano//mm.h>
#include<nano/xenSchedule.h>
#include<nano/console.h>
extern void exit();
int my_strcmp(const char* s1,const char* s2){
	if(s1 == NULL || s2 == NULL){//check for NULL
		xenScheduleShutdown(0);//wrong error code i think not sure
	}
	int i;
	int j = 0;
	while(s1[j] != '\0'){
		j++;
	}//get size of s1 and s2
	int k = 0;
	while(s2[k] != '\0'){
		k++;
	}
	for(i = 0;i<j;i++){// get s
			if(s2[i] == '\0' && s1[i] != '\0'){
				return 1;//reached end of s2 before s1
			} else if(s2[i] < s1[i]){
				return 1;//s1 is bigger at i
			} else if(s1[i] < s2[i]){
				return -1;//opposite last one
			}
	}
	if(j == k){
		return 0;//same size
	}
	return -1;//s1 reached end before s2
}
int my_strncmp(const char* s1, const char* s2, size_t n){
	if(s1 == NULL || s2 == NULL){
		xenScheduleShutdown(0);//is this the right exit code?
	}
	int i;
	for(i = 0;i<n;i++){//same as prev minus condition for end with if before return
			if(s2[i] == '\0' && s1[i] != '\0'){
				return 1;
			} else if(s2[i] < s1[i]){
				return 1;
			} else if(s1[i] < s2[i]){
				return -1;
			}
	}
	return 0;
}
char* my_strcat(char *dest, const char* src){
	int i= 0;
	while(dest[i] != '\0'){
		i++;
	}//get size
	int j; // used linux man page example implementation for this part with some small changes like no sizeof()
	for(j = 0; src[j] != '\0';j++){
		dest[i+j] = src[j];
	}
	dest[i+j] = '\0';//\0 terminate just in case
	return dest;
}
char* my_strncat(char *dest, const char* src, size_t n){//same as prev with n max rather than to the end
	if(src == NULL || dest == NULL){
		xenScheduleShutdown(0);
	}
	int i = 0;
	while(dest[i] != '\0'){
		i++;
	}
	int j;
	for(j = 0;j<n && src[j] != '\0';j++){
		dest[i+j] = src[j];
	}
	dest[i+j] = '\0';
	return dest;
}
char * my_strcpy(char * dest, const char* src){
	if(src == NULL){
		xenScheduleShutdown(0);
	}
	int i = 0;
	while(src[i] != '\0'){
		i++;
	}
	int j;
	for(j = 0;j<i;j++){// copy char by char
		dest[j] = src[j];
	}
	dest[j+1] = '\0';//terminate
	return dest;
}
char * my_strncpy(char * dest, const char* src, size_t n){
	if(src == NULL){
		xenScheduleShutdown(0);
	}
	int i = 0;
	while(src[i] != '\0'){
		i++;
	}
	if(i < n){
		xenScheduleShutdown(0);
	}	
	int j;
	for(j = 0;j<n;j++){
		dest[j] = src[j];
	}
	dest[j+1] = '\0';
	return dest;
}
