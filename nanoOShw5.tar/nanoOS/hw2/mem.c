#include<unistd.h>
#include<stddef.h>
int my_memcmp(const void* s1, const void* s2, size_t n){
	char* s1_char = (char *)s1;
	char * s2_char = (char *)s2;
	int i;
	for(i = 0;i<n;i++){//compare char by char
			if(s2_char[i] < s1_char[i]){
				return 1;
			} else if(s1_char[i] < s2_char[i]){
				return -1;
			}
	}
	return 0;
}

void* my_memset(void *s, int c, size_t n){	
	unsigned char * s_char = s;
	while(n--){// used https://aticleworld.com/memset-in-c for s_char delcaration and use in loop after trying to make it work myself using s_char[j] = c; 
		*s_char++ = (unsigned char)c;
	}
	return s;
}
void * my_memcpy(void * dest, const void* src, size_t n){	
	int j;
	char* dest_char = (char*)dest;
	char * src_char = (char *)src;
	for(j = 0;j<n;j++){//compy char by char
		dest_char[j] = src_char[j];
	}
	return dest_char;
}
