#include<nano/memstrprint.h>
#include<nano/common.h>
char* convert(unsigned int, int);
void _printf(char * src);
int my_printf(char* format,...) // refrenced https://stackoverflow.com/questions/6384856/how-to-know-size-of-int-without-sizeof
// along with https://stackoverflow.com/questions/1735236/how-to-write-my-own-printf-in-c
{	
    char *traverse; 
    unsigned int i;
    long j = 0;
    char *s;
//    char * final;
 
    va_list arg; 
    va_start(arg, format); 

    for(traverse = format; *traverse != '\0'; traverse++) 
    { 
        while( *traverse != '%' ) 
        { 
            if(*traverse == '\0'){//end of string
		    return j;
 	    }
	    char temp[2];
	   temp[0] = *traverse;
	    temp[1] = '\0';
	    _printf(temp);//print any char not part of an arg one by one
            traverse++; 
	    j++;
        } 
        traverse++; 

        switch(*traverse) //found % get type
        { 
            case 'd' : i = va_arg(arg,int);         //Fetch Decimal/Integer argument
			int sizeof_int = (char*)((&i)+1) - (char*)(&i);
			if(sizeof_int > 32){
				_printf("int to large");
			}
			j += sizeof_int;
                        if(i<0) 
                        { 
                            i = -i;
                            _printf("-");//negative 
                        }
                        _printf(convert(i,10));
                        break; 
	    case 'u' : i = va_arg(arg,unsigned int);         //Fetch unsigned int
			int sizeof_int2 = (char*)((&i)+1) - (char*)(&i);
			if(sizeof_int2 > 32){
				_printf("int to large");
			}
			j += sizeof_int2;
                        _printf(convert(i,10));
                        break; 
	    case 's': s = va_arg(arg,char *);       //Fetch string
				int p = 0;
				while(s[p] != '\0'){
					p++;
				}
				j += p;
                        	_printf(s); 
                        	break; 
            case 'x': i = va_arg(arg,unsigned int); //Fetch Hexadecimal representation
                        int sizeof_int3 = (char*)((&i)+1) - (char*)(&i);
			if(sizeof_int3 > 32){
				_printf("int to large");
			}
			j += sizeof_int3;
			_printf(convert(i,16));
                        break;
	    case 'l':
		traverse++;
		switch(*traverse) //found l now grab second char
       		{
            		case 'd' : i = va_arg(arg,long);         //Fetch Decimal/Integer argument
				int sizeof_int4 = (char*)((&i)+1) - (char*)(&i);
				if(sizeof_int4 > 64){
					_printf("int to large");
				}
				j += sizeof_int4;
                        	if(i<0) 
                        	{ 
                            		i = -i;
                            		_printf("-"); 
                        	}
                        	_printf(convert(i,10));
                        	break; 
            		case 'x': i = va_arg(arg,unsigned int); //Fetch Hexadecimal representation
                        	int sizeof_int5 = (char*)((&i)+1) - (char*)(&i);
				if(sizeof_int5 > 64){
					_printf("int to large");
				}
				j += sizeof_int5;
				_printf(convert(i,16));
                        	break;
			case 'u' : i = va_arg(arg,unsigned int);         //Fetch unsigned int
				int sizeof_int6 = (char*)((&i)+1) - (char*)(&i);
				if(sizeof_int6 > 64){//size checks lots all th same basically
					_printf("int to large");
				}
				j+= sizeof_int6;
                        	_printf(convert(i,10));
                        	break; 
		}
		break;
        }
    } 
    va_end(arg);
    return j; //running size total
} 

char *convert(unsigned int num, int base) 
{ 
    static char Representation[]= "0123456789ABCDEF";//this is a clever thing from the stack overflow post to use modulus and the definition of numbers in hex octal and decimal to store in a buffer to convert as needed
    static char buffer[65]; //changed size to deal with longs
    char *ptr; 

    ptr = &buffer[64]; 
    *ptr = '\0'; 
    do 
    { 
        *--ptr = Representation[num%base]; 
        num /= base; 
    }while(num != 0); 
    
    return(ptr); 
}

void _printf(char * src){
	int i = 0;
	while(src[i] != '\0'){
		i++;
	}//get size then write
	xencons_rx(src,i);
}
	
