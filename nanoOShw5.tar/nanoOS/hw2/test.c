//#include<nano/memstrprint.h>
//int my_test(){
// char * test = malloc(24);
// int * my_int = malloc(sizeof(int)*8);
// double * double_test = malloc(sizeof(double));
// *double_test = 222;
// my_int[0] = 2023;
// my_int[1] = 12345;
// my_printf("%d",my_int[0]);
// my_printf("%d",my_int[1]);
// my_printf("%d",*double_test);
// my_strcpy(test,"testing123");
// my_printf("%s",*test);
// return 0;
//}
