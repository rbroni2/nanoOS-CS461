/*****************************************************************************
 * startKernel.c
 *
 * Assorted crap goes here, including the initial C entry point, jumped at
 * from head.S.
 *
 * Copyright (c) 2002-2003, K A Fraser & R Neugebauer
 * Copyright (c) 2005, Grzegorz Milos, Intel Research Cambridge
 * Copyright (c) 2006, Robert Kaiser, FH Wiesbaden
 * Copyright (c) 2008, Andrei Warkentin
 * Copyright (c) 2010, Jon Solworth
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <nano//common.h>
#include <nano//mm.h>
#include <nano/xenEvent.h>
#include <nano/time.h>
#include <nano/version.h>
#include <nano/xenGrant.h>
#include <nano/initialStore.h>
#include <nano/xenbus.h>
#include <nano/timer.h>
#include <xen/features.h>
#include <xen/version.h>
#include <nano/xenSchedule.h>
#include <nano/blkfront.h>
#include <nano/arg.h>
#include <nano/console.h>
#include <nano/interruptDeferred.h>
#include <nano/schedPrivileged.h>
#include <nano/archPageTable.h>
#include<nano/memstrprint.h>

u8 xen_features[XENFEAT_NR_SUBMAPS * 32];

bool logShadowdaemon = false;
bool consoleImmediate;

char hello[] = "Bootstrapping NanoOS...\n";

void masterEventCreateAndExecute(start_info_t *si);

void *malloc(size_t s) { return 0; }

//______________________________________________________________________________
/// reports back xen features that ethos may need to know about
//______________________________________________________________________________
void
setupXenFeatures(void)
{
    xen_feature_info_t fi;
    int i, j;

    for (i = 0; i < XENFEAT_NR_SUBMAPS; i++)
	{
	    fi.submap_idx = i;
	    if (HYPERVISOR_xen_version(XENVER_get_features, &fi) < 0)
		break;

	    for (j=0; j<32; j++)
		xen_features[i*32+j] = !!(fi.submap & 1<<j);
	}
}

//______________________________________________________________________________
/// Initial C entry point.
//______________________________________________________________________________
void
startKernel(start_info_t *si)
{
    
    // this must be turned on in Xen, standard distributions have it off
    // (void) HYPERVISOR_console_io(CONSOLEIO_write, strlen(hello), hello);

    // kernelArgInit((char *)si->cmd_line);

    //debugXprintOn(debugEnvelope);

    archInit(si);

    trapInit();

    // Set up events.
    xenEventInit();

    // Enable event delivery. This is disabled at start of day.
    __sti();

    // Init the console driver.
    consoleInit();
//    timeInit();
    // Initialize console double-buffering.
    consoleImmediate = true;

    // Print out some info.
    xprintLog(hello);
    xprintLog("NanoOS kernel version: $[str]\n", kernel_version);
    xprintLog("NanoOS build info:\n");
    printfLog("start_info:     %p\n",    si);
    printfLog("  nr_pages:     %lu\n",     si->nr_pages);
    printfLog("  shared_inf:   %08lx\n", si->shared_info);
    printfLog("  pt_base:      %p\n",      (void *)si->pt_base);
    printfLog("  mod_start:    0x%lx\n", si->mod_start);
    printfLog("  mod_len:      %lu\n",   si->mod_len);
    printfLog("  flags:        0x%x\n",  (unsigned int)si->flags);
    printfLog("  cmd_line:     %s\n",
	      si->cmd_line ? (const char *)si->cmd_line : "NULL");

    archPrintInfo();

    setupXenFeatures();
    //kernelArgPrint();
	

// Things commented out are for testing and code that worked but not when
// other code was running or didn't completely work like user input

    // your code goes here!
  //  my_test();	
//    evtchn_bind_virq_t op;
  //  op.virq = VIRQ_TIMER;
   // op.vcpu = 0;
   // int status = HYPERVISOR_event_channel_op(EVTCHNOP_bind_virq, &op);
   // if(0 != status){
//	printfLog("error binding timer %d\n", status);
  //  }
//    timeOneShotSet(50000000);
  //  printfLog("before loop waiting for 500000000000\n";
//	my_printf("hello world!\n");
//	char * test = "hello again!";
//	char * test2 = "asdfghjklkjh";
//	my_strcpy(test2,test);
//	my_printf("%s\n",test2);
//	int i = my_strcmp("hello everyone!", "hello world!\n");
//	my_printf("%i\n", i);
//	char * test3 = my_strcat(test2,test);
//	my_printf("%s\n", test);
//	_cli();
//	my_printf("%s\n", test3);
  //  while(1){// timer works woohoo now for user input
	// have seen that a user inputted something but what they typed idk
	// using HandlerDeferred and xencons_rx
//	xenEventBind(console_event, console_event_handler, data);
	
//	timeOneShotSet(50000000);// why not stopping for specificied time
	// yield was causing problem it is now working
//	__cli();
//	consoleHandlerDeferred(); uncommenting this checks for user typing
//	but commands don't want to work
//	__cli();

//	if(timerInterrupt.occured != timerInterrupt.serviced){
//		printfLog("before Block\n");
//		timeOneShotSet(0);
//		HYPERVISOR_shared_info->wc_nsec = NOW();
//		HYPERVISOR_shared_info->wc_sec = NOW() * 1000000000;
//		xenScheduleBlock();
////		printfLog("after Block\n");

//		break;
//	}
//	printfLog("loop\n");
//	__sti();
  //  }
    //printfLog("time works exiting\n");
//    currentPt = (pt_t) start_info.pt_base;
    setCurrentPageTable(si->pt_base);
    removeTest(si->pt_base);
//  archPageTableSwitch(currentPt);//sets currentPt for use in function;
//    MyPageTablePrint();
   //xenScheduleBlock();
 //  setCurrent(si->pt_base);
//    MyPageTableWalk(si->pt_base);
//	archPteGet((pt_t)si->pt_base, si->pt_base);	
 // this works and uses ptePrint; 
  // couldn't figure out tablePrint seems to be walk but for the whole table
  // instead of one part but idk how to handle that :/
 //   xenScheduleYield();
    xenScheduleShutdown(0);
}

